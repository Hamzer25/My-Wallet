import { ethers } from 'ethers';

// Interface to define the structure of wallet data
interface WalletData {
  address: string;
  privateKey: string;
}

// Set to 'mainnet' or 'testnet' based on your testing needs
const ENVIRONMENT = 'mainnet';

// Mainnet and testnet RPC URLs
const MAINNET_RPC_1 = 'https://site1.moralis-nodes.com/eth/d7e00d47db374e1ca4fbbd61b6f67d52';
const MAINNET_RPC_2 = 'https://site2.moralis-nodes.com/eth/d7e00d47db374e1ca4fbbd61b6f67d52';

const TESTNET_RPC_1 = 'https://site1.moralis-nodes.com/sepolia/8dff10e2dcd6453e9242a3e37972e002';
const TESTNET_RPC_2 = 'https://site2.moralis-nodes.com/sepolia/8dff10e2dcd6453e9242a3e37972e002';

// Choose the provider based on the environment
const provider = new ethers.JsonRpcProvider(
  ENVIRONMENT === 'mainnet' ? MAINNET_RPC_1 : TESTNET_RPC_1
);

// Function to generate a new Ethereum wallet
export async function generateWallet(): Promise<WalletData> {
  try {
    // Create a new random wallet connected to the chosen provider
    const wallet = ethers.Wallet.createRandom().connect(provider);

    // Validate that the wallet has been created successfully
    if (!wallet.address || !wallet.privateKey) {
      throw new Error('Failed to generate wallet credentials');
    }

    console.log(`Wallet generated on ${ENVIRONMENT}:`, wallet.address);

    // Fetch and log the balance of the generated wallet
    const balance = await provider.getBalance(wallet.address);
    const formattedBalance = balance ? ethers.formatEther(balance) : '0.0';
    console.log('Initial Balance:', formattedBalance, 'ETH');

    // Return the wallet address and private key
    return {
      address: wallet.address,
      privateKey: wallet.privateKey,
    };
  } catch (error: any) {
    // Log the error details for better debugging
    if (error instanceof Error) {
      console.error('Wallet generation error:', error.message);
    } else {
      console.error('Wallet generation error:', JSON.stringify(error));
    }
    throw new Error('Failed to generate wallet: ' + (error.message || JSON.stringify(error)));
  }
}

// Function to fetch the balance of a given address
export async function getBalance(address: string): Promise<string> {
  try {
    const balance = await provider.getBalance(address);
    return balance ? ethers.formatEther(balance) : '0.0';
  } catch (error: any) {
    console.error('Error fetching balance:', error);
    return 'Error fetching balance';
  }
}