import axios from 'axios';

const CMC_API_KEY = 'dfaa0ff2-b720-46dd-8854-a0490c9237fe';
const CMC_API_URL = 'https://pro-api.coinmarketcap.com/v1';

export interface TokenInfo {
  id: number;
  name: string;
  symbol: string;
  logo: string;
  price: number;
  change24h: number;
  marketCap: number;
  volume24h: number;
}

export const TOKEN_ADDRESSES = {
  ETH: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
  USDT: '0xdAC17F958D2ee523a2206206994597C13D831ec7',
  BNB: '0xB8c77482e45F1F44dE1745F52C74426C631bDD52',
  SXP: '0x8CE9137d39326AD0cD6491fb5CC0CbA0e089b6A9'
} as const;

export const SUPPORTED_TOKENS = Object.keys(TOKEN_ADDRESSES);

// Ensure data is serializable before caching
let tokenDataCache: Record<string, TokenInfo> = {};
let lastFetchTimestamp = 0;
const CACHE_DURATION = 30000; // 30 seconds

function sanitizeTokenData(data: any): TokenInfo {
  return {
    id: Number(data.id) || 0,
    name: String(data.name || ''),
    symbol: String(data.symbol || ''),
    logo: String(data.logo || ''),
    price: Number(data.quote?.USD?.price || 0),
    change24h: Number(data.quote?.USD?.percent_change_24h || 0),
    marketCap: Number(data.quote?.USD?.market_cap || 0),
    volume24h: Number(data.quote?.USD?.volume_24h || 0)
  };
}

// Retry logic for fetching data
async function fetchWithRetry(url: string, options: any, retries = 3) {
    for (let i = 0; i < retries; i++) {
        try {
            return await axios.get(url, options);
        } catch (error) {
            if (i === retries - 1) throw error; // rethrow last error
            console.log(`Retrying... (${i + 1})`);
        }
    }
}

export async function getTokenPrices(): Promise<Record<string, TokenInfo>> {
  const now = Date.now();
  
  if (now - lastFetchTimestamp < CACHE_DURATION && Object.keys(tokenDataCache).length > 0) {
    return { ...tokenDataCache };
  }

  try {
    const symbols = SUPPORTED_TOKENS.join(',');
    
    console.log("Attempting to fetch token prices...");

    const [metadataResponse, quotesResponse] = await Promise.all([
      fetchWithRetry(`${CMC_API_URL}/cryptocurrency/info`, {
        headers: { 'X-CMC_PRO_API_KEY': CMC_API_KEY },
        params: { symbol: symbols }
      }),
      fetchWithRetry(`${CMC_API_URL}/cryptocurrency/quotes/latest`, {
        headers: { 'X-CMC_PRO_API_KEY': CMC_API_KEY },
        params: { symbol: symbols }
      })
    ]);

    const metadata = metadataResponse.data?.data || {};
    const quotes = quotesResponse.data?.data || {};
    const result: Record<string, TokenInfo> = {};

    for (const symbol of SUPPORTED_TOKENS) {
      const tokenMetadata = metadata[symbol];
      const tokenQuote = quotes[symbol];

      if (tokenMetadata && tokenQuote) {
        const tokenData = {
          ...tokenMetadata,
          quote: tokenQuote.quote
        };
        
        result[symbol] = sanitizeTokenData(tokenData);
      }
    }

    tokenDataCache = { ...result };
    lastFetchTimestamp = now;

    return result;
  } catch (error) {
    console.error('Error fetching token data:', error);
    if (axios.isAxiosError(error)) {
        console.error('Axios error message:', error.message);
        if (error.response) {
            console.error('Response data:', error.response.data);
            console.error('Response status:', error.response.status);
        }
    }
    return { ...tokenDataCache }; // Return cached data in case of error
  }
}
