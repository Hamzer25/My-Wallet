import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { toast } from 'react-hot-toast';
import { db } from './firebase';
import { collection, addDoc, query, where, getDocs, updateDoc, doc, orderBy, onSnapshot, limit } from 'firebase/firestore';
import { encrypt, decrypt, createSignature } from './crypto';

interface BinanceCredentials {
  apiKey: string;
  secretKey: string;
}

export interface Transaction {
  id: string;
  type: 'DEPOSIT' | 'WITHDRAWAL' | 'BINANCE_TRANSFER';
  token: string;
  amount: string;
  status: 'PENDING' | 'COMPLETED' | 'FAILED';
  timestamp: number;
  txHash?: string;
  error?: string;
  userId: string;
  destination?: string;
}

interface BinanceStore {
  credentials: BinanceCredentials | null;
  isConnected: boolean;
  isVerified: boolean;
  transactions: Transaction[];
  setCredentials: (creds: BinanceCredentials, userId: string) => Promise<void>;
  clearCredentials: () => void;
  addTransaction: (tx: Omit<Transaction, 'id' | 'timestamp'>) => Promise<string>;
  getTransactions: (userId: string) => Promise<void>;
  updateTransactionStatus: (txId: string, status: Transaction['status'], error?: string) => Promise<void>;
  subscribeToTransactions: (userId: string, callback: (transactions: Transaction[]) => void) => () => void;
}

export const useBinanceStore = create<BinanceStore>()(
  persist(
    (set, get) => ({
      credentials: null,
      isConnected: false,
      isVerified: false,
      transactions: [],

      setCredentials: async (creds, userId) => {
        try {
          const isValid = await validateBinanceCredentials(creds);
          if (!isValid) {
            throw new Error('Invalid Binance API credentials');
          }

          const encryptedApiKey = await encrypt(creds.apiKey);
          const encryptedSecretKey = await encrypt(creds.secretKey);

          const userRef = doc(db, 'users', userId);
          await updateDoc(userRef, {
            binanceApiKey: encryptedApiKey,
            binanceSecretKey: encryptedSecretKey,
            binanceConnected: true
          });

          set({
            credentials: {
              apiKey: encryptedApiKey,
              secretKey: encryptedSecretKey
            },
            isConnected: true,
            isVerified: true
          });

          await get().getTransactions(userId);
          toast.success('Binance account connected successfully');
        } catch (error: any) {
          console.error('Binance connection error:', error.message || error);
          toast.error(error.message || 'Failed to connect Binance account');
          throw error;
        }
      },

      clearCredentials: () => {
        set({ credentials: null, isConnected: false, isVerified: false, transactions: [] });
        toast.success('Binance account disconnected');
      },

      addTransaction: async (tx) => {
        try {
          const txDoc = await addDoc(collection(db, 'transactions'), {
            ...tx,
            timestamp: Date.now()
          });

          const newTx: Transaction = {
            ...tx,
            id: txDoc.id,
            timestamp: Date.now()
          };

          set((state) => ({
            transactions: [...state.transactions, newTx].sort((a, b) => b.timestamp - a.timestamp)
          }));

          return txDoc.id;
        } catch (error) {
          console.error('Transaction save error:', error);
          throw new Error('Failed to save transaction');
        }
      },

      getTransactions: async (userId) => {
        try {
          const q = query(
            collection(db, 'transactions'),
            where('userId', '==', userId),
            orderBy('timestamp', 'desc'),
            limit(100)
          );

          const querySnapshot = await getDocs(q);
          const transactions: Transaction[] = [];

          querySnapshot.forEach((doc) => {
            transactions.push({ id: doc.id, ...doc.data() } as Transaction);
          });

          set({ transactions });
        } catch (error) {
          console.error('Transaction fetch error:', error);
          throw new Error('Failed to fetch transactions');
        }
      },

      updateTransactionStatus: async (txId, status, error) => {
        try {
          const txRef = doc(db, 'transactions', txId);
          await updateDoc(txRef, {
            status,
            ...(error && { error }),
            updatedAt: Date.now()
          });

          set((state) => ({
            transactions: state.transactions.map((tx) =>
              tx.id === txId ? { ...tx, status, error } : tx
            )
          }));
        } catch (error) {
          console.error('Transaction update error:', error);
          throw new Error('Failed to update transaction status');
        }
      },

      subscribeToTransactions: (userId, callback) => {
        const q = query(
          collection(db, 'transactions'),
          where('userId', '==', userId),
          orderBy('timestamp', 'desc'),
          limit(100)
        );

        return onSnapshot(q, (snapshot) => {
          const transactions: Transaction[] = [];
          snapshot.forEach((doc) => {
            transactions.push({ id: doc.id, ...doc.data() } as Transaction);
          });
          callback(transactions);
          set({ transactions });
        }, (error) => {
          console.error('Transaction subscription error:', error);
          toast.error('Failed to load transactions. Please refresh the page.');
        });
      }
    }),
    {
      name: 'binance-storage',
      partialize: (state) => ({ credentials: state.credentials, isVerified: state.isVerified })
    }
  )
);

async function validateBinanceCredentials(creds: BinanceCredentials): Promise<boolean> {
  try {
    const timestamp = Date.now();
    const queryString = `timestamp=${timestamp}`;
    const signature = await createSignature(queryString, creds.secretKey);

    const response = await fetch(`https://api.binance.com/api/v3/account?${queryString}&signature=${signature}`, {
      headers: {
        'X-MBX-APIKEY': creds.apiKey,
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      const errorData = await response.json();
      console.error('Binance validation error:', errorData);
      throw new Error(errorData.msg || 'Invalid API credentials');
    }

    const tradingStatusResponse = await fetch(`https://api.binance.com/sapi/v1/account/apiTradingStatus?${queryString}&signature=${signature}`, {
      headers: {
        'X-MBX-APIKEY': creds.apiKey,
        'Content-Type': 'application/json',
      },
    });

    if (!tradingStatusResponse.ok) {
      const tradingStatusError = await tradingStatusResponse.json();
      console.error('Binance trading permission error:', tradingStatusError);
      throw new Error(tradingStatusError.msg || 'API key does not have trading permissions');
    }

    return true;
  } catch (error: any) {
    console.error('Binance validation error:', error.message || error);
    return false;
  }
}

interface TransferParams {
  amount: string;
  symbol: string;
  walletAddress: string;
  userId: string;
}

export async function initiateBinanceTransfer({ amount, symbol, walletAddress, userId }: TransferParams) {
  const store = useBinanceStore.getState();
  const credentials = store.credentials;

  if (!credentials || !store.isVerified) {
    throw new Error('Binance credentials are not verified');
  }

  try {
    const timestamp = Date.now();
    const queryString = `timestamp=${timestamp}`;
    const apiKey = await decrypt(credentials.apiKey);
    const secretKey = await decrypt(credentials.secretKey);

    const txId = await store.addTransaction({
      type: 'BINANCE_TRANSFER',
      token: symbol,
      amount,
      status: 'PENDING',
      userId,
      destination: 'Binance'
    });

    const balanceSignature = await createSignature(queryString, secretKey);
    const balanceResponse = await fetch(`https://api.binance.com/api/v3/account?${queryString}&signature=${balanceSignature}`, {
      headers: {
        'X-MBX-APIKEY': apiKey,
        'Content-Type': 'application/json',
      },
    });

    if (!balanceResponse.ok) {
      throw new Error('Failed to check balance');
    }

    const balanceData = await balanceResponse.json();
    const balance = balanceData.balances.find((b: any) => b.asset === symbol);

    if (!balance || parseFloat(balance.free) < parseFloat(amount)) {
      await store.updateTransactionStatus(txId, 'FAILED', 'Insufficient balance');
      throw new Error('Insufficient balance');
    }

    const transferParams = new URLSearchParams({
      type: 'MAIN_UMFUTURE',
      asset: symbol,
      amount: amount,
      timestamp: timestamp.toString()
    });

    const transferSignature = await createSignature(transferParams.toString(), secretKey);
    const transferResponse = await fetch(`https://api.binance.com/sapi/v1/asset/transfer?${transferParams}&signature=${transferSignature}`, {
      method: 'POST',
      headers: {
        'X-MBX-APIKEY': apiKey,
        'Content-Type': 'application/json',
      },
    });

    if (!transferResponse.ok) {
      const transferError = await transferResponse.json();
      console.error('Transfer error:', transferError);
      await store.updateTransactionStatus(txId, 'FAILED', transferError.msg);
      throw new Error('Transfer failed: ' + transferError.msg);
    } else {
      const transferData = await transferResponse.json();
      await store.updateTransactionStatus(txId, 'COMPLETED');
      return transferData;
    }
  } catch (error: any) {
    console.error('Transfer error:', error.message || error);
    toast.error('Transfer error: ' + (error.message || 'An error occurred'));
    throw error;
  }
}
