import { initializeApp } from 'firebase/app';
import { 
  getAuth, 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword, 
  signOut, 
  User,
  browserLocalPersistence,
  setPersistence
} from 'firebase/auth';
import { 
  getFirestore, 
  doc, 
  setDoc, 
  getDoc,
  initializeFirestore,
  persistentLocalCache,
  persistentSingleTabManager,
  updateDoc, 
  increment
} from 'firebase/firestore';
import { toast } from 'react-hot-toast';
import { generateWallet } from './wallet';
import { encrypt } from './crypto';

const firebaseConfig = {
  apiKey: "AIzaSyCx5j0j942udEFfu8URxVyFNjBIfre46gM",
  authDomain: "crypto-wallet-4df73.firebaseapp.com",
  projectId: "crypto-wallet-4df73",
  appId: "1:665014233385:web:767e6cfed2696c0046af38"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

setPersistence(auth, browserLocalPersistence).catch((error) => {
  console.error("Persistence Setup Error:", error);
});

const db = initializeFirestore(app, {
  localCache: persistentLocalCache({
    tabManager: persistentSingleTabManager()
  })
});

// Helper function to validate Binance credentials
const validateBinanceCredentials = (apiKey: string, secret: string): boolean => {
  if (!apiKey || !secret) {
    console.error("Binance validation error: Missing API key or secret.");
    return false;
  }
  // Additional validations can be added here, if necessary
  return true;
};

// Set Binance credentials and validate
export const setCredentials = async (userId: string, apiKey: string, secret: string): Promise<void> => {
  try {
    if (!validateBinanceCredentials(apiKey, secret)) {
      throw new Error("Invalid Binance credentials.");
    }

    const userRef = doc(db, 'users', userId);
    await updateDoc(userRef, {
      binanceApiKey: apiKey,
      binanceSecret: secret
    });

    toast.success("Binance credentials set successfully.");
  } catch (error: any) {
    console.error("Binance connection error:", error);
    toast.error("Failed to connect to Binance. Please check your API key and secret.");
    throw error;
  }
};

// Fetch wallet address for the given user ID
export const fetchWalletAddress = async (userId: string): Promise<string | null> => {
  try {
    const userDoc = doc(db, 'users', userId);
    const userSnapshot = await getDoc(userDoc);

    if (userSnapshot.exists()) {
      const userData = userSnapshot.data();
      return userData.walletAddress || null;
    }
    return null;
  } catch (error) {
    console.error("Fetch Wallet Address Error:", error);
    return null;
  }
};

// Sign up user and create user document in Firestore
export const signUp = async (email: string, password: string): Promise<User> => {
  try {
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);

    const userData = {
      email: userCredential.user.email,
      createdAt: new Date().toISOString(),
      walletAddress: null,
      encryptedPrivateKey: null,
      binanceApiKey: null,
      usdtBalance: 0,
      sepolia_ethBalance: 0,
      sxpBalance: 0,
      bnbBalance: 0
    };

    const userRef = doc(db, 'users', userCredential.user.uid);
    await setDoc(userRef, userData);

    toast.success('Account created successfully!');
    return userCredential.user;
  } catch (error: any) {
    console.error("Sign Up Error:", error);
    const errorMessage = error.code === 'auth/email-already-in-use' 
      ? 'Email already in use'
      : error.code === 'auth/weak-password'
      ? 'Password should be at least 6 characters'
      : 'Failed to create account';
    toast.error(errorMessage);
    throw error;
  }
};

// Sign in user
export const signIn = async (email: string, password: string): Promise<User> => {
  try {
    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    toast.success('Signed in successfully!');
    return userCredential.user;
  } catch (error: any) {
    console.error("Sign In Error:", error);
    const errorMessage = error.code === 'auth/wrong-password' || error.code === 'auth/user-not-found'
      ? 'Invalid email or password'
      : 'Failed to sign in';
    toast.error(errorMessage);
    throw error;
  }
};

// Log out user
export const logOut = async (): Promise<void> => {
  try {
    await signOut(auth);
    toast.success('Signed out successfully!');
  } catch (error: any) {
    console.error("Sign Out Error:", error);
    toast.error('Failed to sign out');
    throw error;
  }
};

// Deposit funds
export const depositFunds = async (uid: string, amount: number, tokenType: string): Promise<void> => {
  const userRef = doc(db, 'users', uid);
  try {
    await updateDoc(userRef, {
      [`${tokenType}Balance`]: increment(amount)
    });
    toast.success(`Deposited ${amount} ${tokenType} successfully.`);
  } catch (error) {
    console.error("Error depositing funds:", error);
    toast.error('Failed to deposit funds.');
  }
};

// Withdraw funds
export const withdrawFunds = async (uid: string, amount: number, tokenType: string): Promise<void> => {
  const userRef = doc(db, 'users', uid);
  try {
    await updateDoc(userRef, {
      [`${tokenType}Balance`]: increment(-amount)
    });
    toast.success(`Withdrew ${amount} ${tokenType} successfully.`);
  } catch (error) {
    console.error("Error withdrawing funds:", error);
    toast.error('Failed to withdraw funds.');
  }
};

export { auth, db };
