import Moralis from 'moralis';
import { EvmChain } from '@moralisweb3/common-evm-utils';
import { db } from '../lib/firebase';
import { doc, setDoc, updateDoc } from 'firebase/firestore';
import { ethers } from 'ethers';

export interface TokenBalance {
  token_address: string;
  name: string;
  symbol: string;
  decimals: number;
  balance: string;
}

const MORALIS_API_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJub25jZSI6IjBhNDUwYTA1LTRkY2MtNDYzOC05MDMxLTRiNDJmYTI4NzhhNyIsIm9yZ0lkIjoiNDEzOTMwIiwidXNlcklkIjoiNDI1MzkwIiwidHlwZUlkIjoiMjA5ZWJhMDYtNzI4My00NjBiLWE0MDYtN2E5YzRjMjcwNjZjIiwidHlwZSI6IlBST0pFQ1QiLCJpYXQiOjE3MzAyOTE4MzgsImV4cCI6NDg4NjA1MTgzOH0.hJchCiMxA7AHoPQ3N1njNIW8YGznisYpcECvCDaN8nY';

// Network-specific token configurations
export const NETWORK_TOKENS = {
  mainnet: [
    {
      token_address: '0xdAC17F958D2ee523a2206206994597C13D831ec7',
      name: 'Tether',
      symbol: 'USDT',
      decimals: 6,
      balance: '0'
    },
    {
      token_address: '0xB8c77482e45F1F44dE1745F52C74426C631bDD52',
      name: 'Binance Coin',
      symbol: 'BNB',
      decimals: 18,
      balance: '0'
    },
    {
      token_address: '0x8CE9137d39326AD0cD6491fb5CC0CbA0e089b6A9',
      name: 'Solar',
      symbol: 'SXP',
      decimals: 18,
      balance: '0'
    }
  ],
  testnet: [
    {
      token_address: '0x7b79995e5f793A07Bc00c21412e50Ecae098E7f9',
      name: 'Sepolia ETH',
      symbol: 'SepoliaETH',
      decimals: 18,
      balance: '0'
    }
  ]
};

let isMoralisStarted = false;

export const initMoralis = async (): Promise<void> => {
  if (isMoralisStarted) return;
  
  try {
    await Moralis.start({
      apiKey: MORALIS_API_KEY,
    });
    isMoralisStarted = true;
  } catch (error) {
    console.error('Moralis initialization failed:', error);
    throw new Error('Failed to initialize Moralis');
  }
};

export const getTokenBalances = async (address: string, network: 'mainnet' | 'testnet'): Promise<TokenBalance[]> => {
  if (!address) {
    console.error('Invalid address provided for fetching token balances.');
    return network === 'mainnet' ? NETWORK_TOKENS.mainnet : NETWORK_TOKENS.testnet;
  }

  try {
    await initMoralis();
    const chain = network === 'mainnet' ? EvmChain.ETHEREUM : EvmChain.SEPOLIA;
    
    const response = await fetch(
      `https://deep-index.moralis.io/api/v2/${address}/erc20?chain=${network === 'mainnet' ? 'eth' : 'sepolia'}`,
      {
        headers: {
          'Accept': 'application/json',
          'X-API-Key': MORALIS_API_KEY,
        },
      }
    );

    if (!response.ok) {
      throw new Error('Failed to fetch token balances from Moralis');
    }

    const tokenData = await response.json();
    const tokens = network === 'mainnet' ? NETWORK_TOKENS.mainnet : NETWORK_TOKENS.testnet;

    return tokens.map(token => {
      const tokenInfo = tokenData.find((t: any) => 
        t.token_address.toLowerCase() === token.token_address.toLowerCase()
      );

      return {
        ...token,
        balance: tokenInfo ? tokenInfo.balance : '0'
      };
    });
  } catch (error) {
    console.error('Failed to fetch token balances:', error);
    return network === 'mainnet' ? NETWORK_TOKENS.mainnet : NETWORK_TOKENS.testnet;
  }
};

export const updateWalletBalance = async (userId: string, address: string, network: 'mainnet' | 'testnet'): Promise<void> => {
  if (!userId || !address) {
    throw new Error('Invalid user ID or address');
  }

  try {
    const balances = await getTokenBalances(address, network);
    const userRef = doc(db, 'users', userId);
    await setDoc(userRef, { 
      balances,
      currentNetwork: network
    }, { merge: true });
  } catch (error) {
    console.error('Error updating wallet balance:', error);
    throw new Error('Failed to update wallet balance');
  }
};

export const depositToWallet = async (userId: string, amount: number): Promise<void> => {
  if (!userId || amount <= 0) {
    throw new Error('Invalid user ID or deposit amount');
  }

  try {
    const userRef = doc(db, 'users', userId);
    const amountInWei = ethers.parseUnits(amount.toString(), 18).toString();
    
    await updateDoc(userRef, {
      'balances': NETWORK_TOKENS.testnet.map(token => 
        token.symbol === 'SepoliaETH' 
          ? { ...token, balance: amountInWei }
          : token
      ),
      lastDeposit: {
        amount: amountInWei,
        timestamp: Date.now(),
      },
    });

    const transactionRef = doc(db, 'transactions', Date.now().toString());
    await setDoc(transactionRef, {
      type: 'DEPOSIT',
      token: 'SepoliaETH',
      amount: amount.toString(),
      status: 'COMPLETED',
      timestamp: Date.now(),
      userId: userId
    });
  } catch (error) {
    console.error('Error during deposit:', error);
    throw new Error('Deposit transaction failed');
  }
};