// Utility functions for encryption/decryption and signing using Web Crypto API

// Function to encrypt data
export async function encrypt(data: string): Promise<string> {
  try {
    const encodedData = new TextEncoder().encode(data);
    const base64Data = btoa(String.fromCharCode(...encodedData));
    return base64Data; // Return the base64 encoded string
  } catch (error) {
    console.error('Encryption error:', error);
    throw new Error('Failed to encrypt data');
  }
}

// Function to decrypt data
export async function decrypt(encryptedData: string): Promise<string> {
  try {
    const decodedData = atob(encryptedData);
    const uint8Array = new Uint8Array([...decodedData].map(char => char.charCodeAt(0)));
    return new TextDecoder().decode(uint8Array); // Decode the Uint8Array to string
  } catch (error) {
    console.error('Decryption error:', error);
    throw new Error('Failed to decrypt data');
  }
}

// Function to create a signature for a message using HMAC and SHA-256
export async function createSignature(message: string, key: string): Promise<string> {
  try {
    const encoder = new TextEncoder();
    const keyData = encoder.encode(key);
    const messageData = encoder.encode(message);

    // Import the key for HMAC signing
    const cryptoKey = await crypto.subtle.importKey(
      'raw',
      keyData,
      { name: 'HMAC', hash: 'SHA-256' },
      false,
      ['sign']
    );

    // Create the signature
    const signature = await crypto.subtle.sign(
      'HMAC',
      cryptoKey,
      messageData
    );

    // Convert the signature to a hex string
    return Array.from(new Uint8Array(signature))
      .map(b => b.toString(16).padStart(2, '0'))
      .join('');
  } catch (error) {
    console.error('Signing error:', error);
    throw new Error('Failed to create signature');
  }
}
