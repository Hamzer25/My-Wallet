import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface WalletState {
  address: string | null;
  balance: string;
  setAddress: (address: string) => void;
  setBalance: (balance: string) => void;
}

// Zustand store with persistent state for wallet information
export const useWalletStore = create<WalletState>()(
  persist(
    (set) => ({
      address: null, // Initial address state
      balance: '0',  // Initial balance state
      setAddress: (address) => set({ address }), // Function to set wallet address
      setBalance: (balance) => set({ balance }), // Function to set wallet balance
    }),
    {
      name: 'wallet-storage', // Key name for localStorage
    }
  )
);
