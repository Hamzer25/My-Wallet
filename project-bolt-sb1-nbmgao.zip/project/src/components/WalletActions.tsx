import React, { useState } from 'react';
import { useBinanceStore, initiateBinanceTransfer } from '../lib/binance';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Select } from './ui/select';
import { toast } from 'react-hot-toast';
import { auth } from '../lib/firebase';
import { depositToWallet, NETWORK_TOKENS } from '../lib/moralis';

interface WalletActionsProps {
  walletAddress: string;
  network: 'mainnet' | 'testnet';
}

export function WalletActions({ walletAddress, network }: WalletActionsProps) {
  const { isConnected, setCredentials, clearCredentials } = useBinanceStore();
  const [showConnectForm, setShowConnectForm] = useState(!isConnected);
  const [apiKey, setApiKey] = useState('');
  const [secretKey, setSecretKey] = useState('');
  const [amount, setAmount] = useState('');
  const [selectedToken, setSelectedToken] = useState('');
  const [loading, setLoading] = useState(false);
  const [depositAmount, setDepositAmount] = useState('');

  // Define supported tokens based on the network
  const supportedTokens = network === 'mainnet' 
    ? NETWORK_TOKENS.mainnet.map((token: { symbol: string }) => token.symbol)
    : NETWORK_TOKENS.testnet.map((token: { symbol: string }) => token.symbol);

  // Handle Binance connection form submission
  const handleConnect = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!auth.currentUser) {
      toast.error('Please sign in first');
      return;
    }

    setLoading(true);
    try {
      await setCredentials(
        { apiKey, secretKey },
        auth.currentUser.uid
      );
      setShowConnectForm(false);
      setApiKey('');
      setSecretKey('');
    } catch (error) {
      console.error('Connection error:', error);
      toast.error('Failed to connect to Binance. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  // Handle the transfer of tokens to Binance
  const handleTransfer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!auth.currentUser) {
      toast.error('Please sign in first');
      return;
    }

    if (!amount || parseFloat(amount) <= 0) {
      toast.error('Please enter a valid amount');
      return;
    }

    if (!selectedToken) {
      toast.error('Please select a token');
      return;
    }

    // Check if the selected token is supported for the mainnet
    if (network === 'mainnet' && !supportedTokens.includes(selectedToken)) {
      toast.error('The selected token is not supported on the mainnet');
      return;
    }

    setLoading(true);
    try {
      await initiateBinanceTransfer({
        amount,
        symbol: selectedToken,
        walletAddress,
        userId: auth.currentUser.uid
      });
      setAmount('');
      toast.success(`Successfully transferred ${amount} ${selectedToken} to Binance`);
    } catch (error: any) {
      console.error('Transfer error:', error);
      toast.error(`Transfer failed: ${error.message || 'An unknown error occurred'}`);
    } finally {
      setLoading(false);
    }
  };

  // Handle deposit action (only for testnet)
  const handleDeposit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!auth.currentUser) {
      toast.error('Please sign in first');
      return;
    }

    if (network !== 'testnet') {
      toast.error('Deposits are only available on testnet');
      return;
    }

    const amount = parseFloat(depositAmount);
    if (!depositAmount || amount <= 0) {
      toast.error('Please enter a valid deposit amount');
      return;
    }

    setLoading(true);
    try {
      await depositToWallet(auth.currentUser.uid, amount);
      setDepositAmount('');
      toast.success(`Successfully deposited ${amount} SepoliaETH to your wallet`);
    } catch (error: any) {
      console.error('Deposit error:', error);
      toast.error(`Deposit failed: ${error.message || 'An unknown error occurred'}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {showConnectForm ? (
        <form onSubmit={handleConnect} className="space-y-4">
          <Input
            value={apiKey}
            onChange={(e) => setApiKey(e.target.value)}
            placeholder="API Key"
            required
          />
          <Input
            value={secretKey}
            onChange={(e) => setSecretKey(e.target.value)}
            placeholder="Secret Key"
            required
            type="password"
          />
          <Button type="submit" loading={loading}>Connect to Binance</Button>
        </form>
      ) : (
        <div className="space-y-6">
          <form onSubmit={handleTransfer} className="space-y-4">
            <h3 className="text-lg font-semibold">Transfer to Binance</h3>
            <Input
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="Amount"
              type="number"
              step="any"
              required
            />
            <Select
              value={selectedToken}
              onChange={(e) => setSelectedToken(e.target.value)}
            >
              <option value="">Select Token</option>
              {supportedTokens.map((token) => (
                <option key={token} value={token}>{token}</option>
              ))}
            </Select>
            <Button type="submit" loading={loading}>Transfer to Binance</Button>
          </form>

          {network === 'testnet' && (
            <form onSubmit={handleDeposit} className="space-y-4">
              <h3 className="text-lg font-semibold">Deposit SepoliaETH</h3>
              <Input
                value={depositAmount}
                onChange={(e) => setDepositAmount(e.target.value)}
                placeholder="Deposit Amount"
                type="number"
                step="any"
                required
              />
              <Button type="submit" loading={loading}>Deposit</Button>
            </form>
          )}
        </div>
      )}
    </div>
  );
}
