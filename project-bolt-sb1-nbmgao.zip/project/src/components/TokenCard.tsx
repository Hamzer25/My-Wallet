import React from 'react';

interface TokenCardProps {
  token: {
    token_address: string;
    symbol: string;
    name: string;
    decimals: number;
    balance: string;
  };
}

export function TokenCard({ token }: TokenCardProps) {
  // Remove the manual calculation and use the pre-formatted balance
  const formattedBalance = token.balance;

  return (
    <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow duration-200">
      <div className="flex items-center space-x-3 mb-4">
        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center">
          <span className="text-gray-700 font-semibold text-lg">
            {token.symbol ? token.symbol[0] : '?'}
          </span>
        </div>
        <div>
          <h3 className="font-bold text-lg">{token.symbol}</h3>
          <p className="text-sm text-gray-500">{token.name}</p>
        </div>
      </div>
      
      <div className="space-y-2">
        <div className="flex justify-between items-center">
          <span className="text-gray-600">Balance:</span>
          <span className="font-medium">
            {parseFloat(formattedBalance).toFixed(6)} {token.symbol}
          </span>
        </div>
      </div>
    </div>
  );
}