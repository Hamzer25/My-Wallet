import React, { useState, useEffect } from 'react';
import { toast } from 'react-hot-toast';
import { auth, fetchWalletAddress } from '../lib/firebase';
import { NETWORK_TOKENS } from '../lib/moralis';

interface DepositAddressProps {
  network: 'mainnet' | 'testnet';
}

export function DepositAddress({ network }: DepositAddressProps) {
  const [selectedToken, setSelectedToken] = useState('');
  const [depositAddress, setDepositAddress] = useState('');

  const supportedTokens = network === 'mainnet'
    ? NETWORK_TOKENS.mainnet.map(token => token.symbol)
    : NETWORK_TOKENS.testnet.map(token => token.symbol);

  useEffect(() => {
    const loadDepositAddress = async () => {
      if (!auth.currentUser) return;
      try {
        const address = await fetchWalletAddress(auth.currentUser.uid);
        if (address) {
          setDepositAddress(address);
        } else {
          toast.error('Failed to load deposit address');
        }
      } catch (error) {
        console.error('Error loading deposit address:', error);
        toast.error('Failed to load deposit address');
      }
    };

    loadDepositAddress();
  }, []);

  useEffect(() => {
    // Reset selected token when network changes
    setSelectedToken('');
  }, [network]);

  return (
    <div className="p-6 bg-white rounded-lg shadow-md">
      <h2 className="text-xl font-bold mb-4">Deposit Address</h2>
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium mb-1">Select Token</label>
          <select
            value={selectedToken}
            onChange={(e) => setSelectedToken(e.target.value)}
            className="border rounded-md p-2"
          >
            <option value="">Select Token</option>
            {supportedTokens.map((token) => (
              <option key={token} value={token}>
                {token}
              </option>
            ))}
          </select>
        </div>

        {depositAddress && selectedToken && (
          <div className="mt-4">
            <label className="block text-sm font-medium mb-1">Your Deposit Address</label>
            <div className="p-3 bg-gray-50 rounded border break-all">
              {depositAddress}
            </div>
            <p className="mt-2 text-sm text-gray-500">
              Send only {selectedToken} to this address on {network}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}