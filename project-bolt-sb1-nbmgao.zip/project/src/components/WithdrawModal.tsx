import React, { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { toast } from 'react-hot-toast';

interface WithdrawModalProps {
  isOpen: boolean;
  onClose: () => void;
  onWithdraw: (amount: string, address: string) => Promise<void>;
  tokenSymbol: string;
}

export function WithdrawModal({ isOpen, onClose, onWithdraw, tokenSymbol }: WithdrawModalProps) {
  const [amount, setAmount] = useState('');
  const [address, setAddress] = useState('');
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!amount || parseFloat(amount) <= 0) {
      toast.error('Please enter a valid amount');
      return;
    }

    if (!address || !address.startsWith('0x') || address.length !== 42) {
      toast.error('Please enter a valid Ethereum address');
      return;
    }

    setLoading(true);
    try {
      await onWithdraw(amount, address);
      onClose();
      setAmount('');
      setAddress('');
    } catch (error) {
      console.error('Withdrawal error:', error);
      toast.error('Failed to withdraw funds. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg p-6 max-w-md w-full">
        <h2 className="text-xl font-bold mb-4">Withdraw {tokenSymbol}</h2>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1">Amount</label>
            <Input
              type="number"
              step="any"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              required
              min="0"
              disabled={loading}
              placeholder={`Enter amount in ${tokenSymbol}`}
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Recipient Address</label>
            <Input
              type="text"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              required
              disabled={loading}
              placeholder="0x..."
            />
          </div>

          <div className="flex space-x-3">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              disabled={loading}
              className="flex-1"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={loading}
              className="flex-1"
            >
              {loading ? 'Processing...' : 'Withdraw'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
