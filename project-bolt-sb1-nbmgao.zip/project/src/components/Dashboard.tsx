import React, { useState, useEffect } from 'react';
import { setDoc, doc, getDoc, onSnapshot } from 'firebase/firestore';
import { db, auth, fetchWalletAddress, logOut } from '../lib/firebase';
import { toast } from 'react-hot-toast';
import { generateWallet } from '../lib/wallet';
import { WalletActions } from './WalletActions';
import { TransactionHistory } from './TransactionHistory';
import { DepositAddress } from './DepositAddress';
import { TokenCard } from './TokenCard';
import { useNavigate } from 'react-router-dom';
import { ethers } from 'ethers';
import { initiateBinanceTransfer } from '../lib/binance';
import { NETWORK_TOKENS, updateWalletBalance } from '../lib/moralis';

export function Dashboard() {
  const [loading, setLoading] = useState(true);
  const [walletAddress, setWalletAddress] = useState<string | null>(null);
  const [network, setNetwork] = useState<'mainnet' | 'testnet'>('testnet');
  const [balances, setBalances] = useState(NETWORK_TOKENS.testnet);
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [withdrawSymbol, setWithdrawSymbol] = useState('');
  const [withdrawAddress, setWithdrawAddress] = useState('');
  const [generatingWallet, setGeneratingWallet] = useState(false);
  const [withdrawing, setWithdrawing] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const loadWalletAddress = async () => {
      if (!auth.currentUser) {
        navigate('/');
        return;
      }

      try {
        const address = await fetchWalletAddress(auth.currentUser.uid);
        if (address) {
          setWalletAddress(address);
          const userDoc = await getDoc(doc(db, 'users', auth.currentUser.uid));
          if (userDoc.exists()) {
            const userData = userDoc.data();
            setNetwork(userData.currentNetwork || 'testnet');
          }
        } else {
          toast.error('No wallet address found. Please generate one.');
        }
      } catch (error) {
        console.error('Failed to fetch wallet address:', error);
        toast.error('Failed to load wallet information');
      } finally {
        setLoading(false);
      }
    };

    loadWalletAddress();
  }, [navigate]);

  useEffect(() => {
    if (auth.currentUser && walletAddress) {
      const userRef = doc(db, 'users', auth.currentUser.uid);

      const unsubscribe = onSnapshot(userRef, (docSnapshot) => {
        if (docSnapshot.exists()) {
          const data = docSnapshot.data();
          setWalletAddress(data.walletAddress || '');
          setNetwork(data.currentNetwork || 'testnet');

          const currentBalances = network === 'mainnet' ? NETWORK_TOKENS.mainnet : NETWORK_TOKENS.testnet;
          setBalances(
            (data.balances || currentBalances).map((token) => {
              try {
                const balance = token.balance || '0';
                const formattedBalance = ethers.formatUnits(balance, token.decimals);
                return { ...token, balance: formattedBalance };
              } catch (error) {
                console.error(`Error formatting balance for ${token.symbol}:`, error);
                return { ...token, balance: '0' };
              }
            })
          );
        }
      }, (error) => {
        console.error("Failed to listen to balance updates:", error);
      });

      return () => unsubscribe();
    }
  }, [network]);

  const handleNetworkSwitch = async () => {
    if (!auth.currentUser || !walletAddress) return;
    
    const newNetwork = network === 'mainnet' ? 'testnet' : 'mainnet';
    setNetwork(newNetwork);
    
    try {
      await updateWalletBalance(auth.currentUser.uid, walletAddress, newNetwork);
      toast.success(`Switched to ${newNetwork}`);
    } catch (error) {
      console.error('Network switch error:', error);
      toast.error('Failed to switch network');
    }
  };

  const handleGenerateWallet = async () => {
    if (!auth.currentUser) {
      toast.error('Please sign in to generate a wallet');
      return;
    }

    setGeneratingWallet(true);
    try {
      const userRef = doc(db, 'users', auth.currentUser.uid);
      const userDoc = await getDoc(userRef);

      if (userDoc.exists() && userDoc.data().walletAddress) {
        toast.error('Wallet address already generated. You cannot generate another one.');
        return;
      }

      const { address, privateKey } = await generateWallet();
      await setDoc(userRef, {
        walletAddress: address,
        encryptedPrivateKey: privateKey,
        currentNetwork: network
      }, { merge: true });

      setWalletAddress(address);
      toast.success('Wallet generated successfully!');
    } catch (error) {
      console.error('Wallet generation error:', error);
      toast.error('Failed to generate wallet. Please try again.');
    } finally {
      setGeneratingWallet(false);
    }
  };

  const handleLogout = async () => {
    try {
      await logOut();
      navigate('/');
    } catch (error) {
      console.error('Logout error:', error);
      toast.error('Failed to sign out');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="space-y-6">
        <div className="bg-white shadow rounded-lg p-6">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h2 className="text-2xl font-bold">Your Portfolio</h2>
              <p className="text-sm text-gray-500 mt-1">Current Network: {network}</p>
            </div>
            <div className="flex space-x-4">
              <button
                onClick={handleNetworkSwitch}
                className="bg-purple-600 text-white px-4 py-2 rounded-md hover:bg-purple-700 transition-colors duration-200"
              >
                Switch to {network === 'mainnet' ? 'Testnet' : 'Mainnet'}
              </button>
              <button
                onClick={handleGenerateWallet}
                className={`bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors duration-200 ${generatingWallet ? 'opacity-50 cursor-not-allowed' : ''}`}
                disabled={generatingWallet}
              >
                {generatingWallet ? 'Generating...' : 'Generate Wallet'}
              </button>
              <button
                onClick={handleLogout}
                className="bg-red-600 text-white px-4 py-2 rounded-md hover:bg-red-700 transition-colors duration-200"
              >
                Logout
              </button>
            </div>
          </div>
          
          {walletAddress && (
            <div className="bg-gray-50 p-4 rounded-md break-all mb-6">
              <p className="text-sm font-medium text-gray-500">Wallet Address</p>
              <p className="mt-1 font-mono text-sm">{walletAddress}</p>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {balances.map((token) => (
              <TokenCard
                key={token.symbol}
                token={token}
                tokenInfo={undefined}
              />
            ))}
          </div>
        </div>

        <div className="bg-white shadow rounded-lg p-6">
          <h2 className="text-xl font-bold mb-4">Binance Transfer</h2>
          <WalletActions walletAddress={walletAddress || ''} network={network} />
        </div>

        <TransactionHistory />
        <DepositAddress network={network} />
      </div>
    </div>
  );
}