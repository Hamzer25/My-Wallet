import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { createRequire } from 'module';

const require = createRequire(import.meta.url);

export default defineConfig({
  plugins: [
    react()
  ],
  server: {
    port: 5173,
    host: true,
  },
  define: {
    global: 'globalThis', // Ensure global is available
    'process.env': {}, // Define process.env to avoid errors
  },
  resolve: {
    alias: {
      'randombytes': require.resolve('randombytes'), // Resolve randombytes
    },
  },
});
